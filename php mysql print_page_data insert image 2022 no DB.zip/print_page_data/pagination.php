<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Pagination</title>
</head>

<body>

    <?php
// Database Connection with mysql database
$connect = mysqli_connect("localhost", "root", "", "image");
if($connect){
    //echo "Success";
}else{
    echo "Fail";
}

global $get_page;

if(isset($_GET['page'])){

    $get_page = $_GET['page'];

}

if($get_page==""|| $get_page=="1"){
    $target_page = 1;
}else{
    $target_page = ($get_page*3)-3;
}

$select = "SELECT * FROM img_upload ORDER BY Id desc limit $target_page,3";
$query = mysqli_query($connect,$select);
while($row = mysqli_fetch_array($query)){

    echo $row['Id'];
    echo $row['name'];
    echo $row['phone'];
    echo $row['image'];
    echo $row['status'];
    echo "<br>";
}

$select2 = "SELECT * FROM img_upload";
$query2 = mysqli_query($connect,$select2);
$count = mysqli_num_rows($query2);

$i = $count/3;
$page = ceil($i);
//echo $page;

for($t=1; $t<=$page; $t++){ ?>

    <div style="display:inline-block; margin-top:10px;">
        <a style="background:green; color:white; padding:10px;" href="pagination.php?page=<?php echo $t; ?>">
    </div>
    <?php echo $t; ?></a>
    <?php
}

?>

</body>

</html>