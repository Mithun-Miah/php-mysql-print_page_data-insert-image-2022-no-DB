<?php
$connect = mysqli_connect('localhost', 'root', '', 'image');

$id = $_GET['idNo']; // Select with database id number

$select = "SELECT * FROM img_upload WHERE Id = $id";
$query = mysqli_query($connect, $select);
$row = mysqli_fetch_array($query);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Report Page</title>
    <link rel="stylesheet" href="show.css">

    <style>
        table {
  width: 100%;
}

table,
th,
td {
  padding: 10px;
  border: 1px solid green;
  border-collapse: collapse;
}
    </style>
</head>

<body>
    <div class="container">
        <a href="image_insert.php">Back Home</a>
        <h1>Reports Show</h1>
        <table>
            <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Phone</th>
            <th>Image</th>
            <th>Print Reports</th>
            </tr>
        </table>
        <tbody>
            <tr>
            <td><?php echo $row['Id'] ?></td>
            <td><?php echo $row['name'] ?></td>
            <td><?php echo $row['phone'] ?></td>
            <td><img src="image_folder/<?php echo $row['image'] ?>" height="100"
                    width="100" alt=""></td>
            <td><button onclick="window.print()" style="font-size:20px;width:100px;border:none;">Print</button></td>
            </tr>
        </tbody>
    </div>

</body>

</html>