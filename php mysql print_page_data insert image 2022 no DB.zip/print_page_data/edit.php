<?php
// IMAGE Data Edit/Update PHP MySQL START CODE HERE
$connect = mysqli_connect('localhost', 'root', '', 'image');
// if($connect){
//     echo "DB Conn Successful";
// }else{
//     echo "DB Conn Failed";
// }
$id = $_GET['idNo']; // Select with database id number

 //For Show Data in Edit page input field
 $read = "SELECT * FROM img_upload WHERE Id=$id";
 $query = mysqli_query($connect, $read);
 $row = mysqli_fetch_array($query);

 if(isset($_POST['edit'])){
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $image_name = $_FILES['image']['name'];
    $tmp_name = $_FILES['image']['tmp_name'];

    $upload = move_uploaded_file($tmp_name, "image_folder/".$image_name); // Image Folder Location set code

    if($upload){
        $update = "UPDATE img_upload SET name = '$name', phone = '$phone', image = '$image_name' where Id = $id";

    $query = mysqli_query($connect, $update);

    if($query){
        echo "<script>alert('Data Update Success')</script>";
    } else{
        echo "<script>alert('Data Update Fail')</script>";
    }

    }else{
        echo "<script>alert('Update Failed !')</script>";
    }
}
// IMAGE EDIT/UPDATE PHP MySQL END CODE HERE

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <title>Image Edit Page</title>
    <link rel="stylesheet" href="edit.css">
</head>

<body>
    <h2 class="title">Image Edit Data</h2>

    <div class="container">
        <a href="image_insert.php">Back Home</a>
        <form action="" enctype="multipart/form-data" method="POST">
            <input type="text" value="<?php echo $row['name'] ?>" name="name" placeholder="Name"> <br><br>
            <input type="text" value="<?php echo $row['phone'] ?>" name="phone" placeholder="Phone"> <br><br>
            <input type="file" value="<?php echo $row['image'] ?>" name="image"> <br><br>
            <button name="edit">Update</button>
        </form>
        <hr>
        <h1>Fetch and Edit Data</h1>


    </div>

</body>

</html>